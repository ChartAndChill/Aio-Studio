#!/usr/bin/env python3
"""Writes the licences of the Rust libraries Aio Studio is built from: every
crate in the dependency graph of aio-gui and aio-cli (normal and build
dependencies), with its version, licence and the licence texts it ships
(LICENSE*, LICENCE*, COPYING*, NOTICE*, UNLICENSE), read from the cargo
registry. Fails when a crate has no licence at all, or only GPL/LGPL ones.

    python3 packaging/rust-licenses.py <out.txt>
"""
import json
import re
import subprocess
import sys
from pathlib import Path

ROOTS = ("aio-gui", "aio-cli")
TEXTS = re.compile(r"^(LICEN[CS]E|COPYING|NOTICE|UNLICENSE)", re.IGNORECASE)


def graph(meta):
    packages = {p["id"]: p for p in meta["packages"]}
    nodes = {n["id"]: n for n in meta["resolve"]["nodes"]}
    workspace = set(meta["workspace_members"])
    todo = [i for i in workspace if packages[i]["name"] in ROOTS]
    seen = set()
    while todo:
        node = todo.pop()
        if node in seen:
            continue
        seen.add(node)
        for dep in nodes[node]["deps"]:
            if any(k["kind"] in (None, "build") for k in dep["dep_kinds"]):
                todo.append(dep["pkg"])
    # By name, then version: the same list on every run.
    return [packages[i] for i in sorted(seen - workspace,
                                        key=lambda i: (packages[i]["name"], packages[i]["version"]))]


def copyleft_only(expression):
    """Whether every choice in an SPDX expression is a GPL or LGPL licence."""
    choices = re.split(r"\s+OR\s+|/", expression)
    return all(re.search(r"\b(A|L)?GPL", c) for c in choices)


def main():
    out = Path(sys.argv[1])
    meta = json.loads(subprocess.run(
        ["cargo", "metadata", "--format-version", "1", "--locked"],
        check=True, capture_output=True, encoding="utf-8").stdout)
    crates = graph(meta)
    problems = []
    lines = ["Rust libraries in Aio Studio", "=" * 28, ""]
    for crate in crates:
        name, version = crate["name"], crate["version"]
        licence = crate.get("license") or ""
        folder = Path(crate["manifest_path"]).parent
        texts = sorted(p for p in folder.iterdir() if p.is_file() and TEXTS.match(p.name))
        if not licence and not texts:
            problems.append(f"{name} {version}: no licence")
        if licence and copyleft_only(licence):
            problems.append(f"{name} {version}: only {licence}")
        lines.append(f"{name} {version} -- {licence or 'see the text below'}")
        if crate.get("repository"):
            lines.append(f"  {crate['repository']}")
        for text in texts:
            lines.append(f"  --- {text.name} ---")
            body = text.read_text(encoding="utf-8", errors="replace").strip()
            lines.extend("  " + l if l else "" for l in body.splitlines())
        lines.append("")
    # UTF-8 everywhere: Windows would use cp1252 and fail on the texts.
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"{len(crates)} crates written to {out}")
    for p in problems:
        print("FAIL:", p, file=sys.stderr)
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()
