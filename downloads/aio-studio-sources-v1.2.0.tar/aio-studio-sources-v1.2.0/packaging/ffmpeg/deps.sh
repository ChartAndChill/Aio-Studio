#!/usr/bin/env bash
# Builds the codec libraries of the minimal FFmpeg as static, position-independent
# libraries into <prefix>: x264, x265, SVT-AV1, libvpx, opus, lame, plus the
# NVENC headers, the text stack: zlib, FreeType, FriBidi, HarfBuzz, libass,
# and whisper.cpp for speech to text. Every source is downloaded once, checked against the SHA-256
# pinned in versions.env, and nothing is compiled unless all checksums match.
# On Linux, VAAPI too: the build machine's libva headers (libva-dev) and
# stand-ins for its libraries, which open the system's libva when used.
#
#   packaging/ffmpeg/deps.sh <target> <prefix>
#
# Targets: x86_64-unknown-linux-gnu, aarch64-apple-darwin, x86_64-apple-darwin
# (cross on Apple Silicon), x86_64-pc-windows-gnu (mingw-w64 cross from Linux).
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
target=${1:?usage: deps.sh <target> <prefix>}
prefix=$(mkdir -p "${2:?usage: deps.sh <target> <prefix>}" && cd "$2" && pwd)
# shellcheck source=versions.env
source "$here/versions.env"
# shellcheck source=license.sh
source "$here/license.sh"
# x264 and x265 are GPL: built for the GPL (Linux) target only.
gpl=$( [ "$(ffmpeg_license "$target")" = gpl ] && echo 1 || echo 0 )

dl=${AIO_DL_CACHE:-$prefix/../dl}
work=${AIO_BUILD_DIR:-$prefix/../build}
mkdir -p "$dl" "$work"
jobs=${JOBS:-$(getconf _NPROCESSORS_ONLN 2>/dev/null || sysctl -n hw.ncpu)}

# --- target settings ---------------------------------------------------------
cross_host="" cmake_extra=() vpx_target="" vpx_cross="" x264_host="" opus_extra="" opus_cflags=""
case "$target" in
  x86_64-unknown-linux-gnu) vpx_target=x86_64-linux-gcc ;;
  aarch64-apple-darwin)     vpx_target=arm64-darwin20-gcc ;;
  x86_64-apple-darwin)
    export CFLAGS="${CFLAGS:-} -arch x86_64" CXXFLAGS="${CXXFLAGS:-} -arch x86_64" LDFLAGS="${LDFLAGS:-} -arch x86_64"
    cross_host=x86_64-apple-darwin; x264_host=x86_64-apple-darwin
    cmake_extra=(-DCMAKE_OSX_ARCHITECTURES=x86_64 -DCMAKE_SYSTEM_PROCESSOR=x86_64)
    vpx_target=x86_64-darwin20-gcc ;;
  x86_64-pc-windows-gnu)
    cross_host=x86_64-w64-mingw32; x264_host=x86_64-w64-mingw32
    # The posix thread model: whisper.cpp's C++ needs std::thread and
    # std::mutex, which MinGW-w64's win32 model lacks before GCC 13. One
    # model for every library, so they all share one C++ runtime.
    export CC=x86_64-w64-mingw32-gcc-posix CXX=x86_64-w64-mingw32-g++-posix AR=x86_64-w64-mingw32-ar RANLIB=x86_64-w64-mingw32-ranlib
    cmake_extra=(-DCMAKE_SYSTEM_NAME=Windows -DCMAKE_SYSTEM_PROCESSOR=x86_64 -DCMAKE_C_COMPILER=$CC -DCMAKE_CXX_COMPILER=$CXX -DCMAKE_RC_COMPILER=x86_64-w64-mingw32-windres)
    vpx_target=x86_64-win64-gcc vpx_cross=x86_64-w64-mingw32-
    # opus turns on the stack protector and _FORTIFY_SOURCE=2, whose helpers
    # (__stack_chk_*, __memcpy_chk) older MinGW-w64 keeps in libssp, which
    # opus.pc does not list: anything linking the static libopus, FFmpeg's
    # configure check included, then fails.
    opus_extra=--disable-stack-protector opus_cflags=-D_FORTIFY_SOURCE=0 ;;
  *) echo "unsupported target: $target" >&2; exit 2 ;;
esac
export PKG_CONFIG_PATH="$prefix/lib/pkgconfig"

# --- download and verify everything first -----------------------------------
sha256() { if command -v sha256sum >/dev/null; then sha256sum "$1"; else shasum -a 256 "$1"; fi | cut -d' ' -f1; }
fetch() { # name url sha256
  local file="$dl/$1"
  [ -f "$file" ] || curl -fsSL --retry 6 --retry-delay 10 --retry-all-errors -o "$file.part" "$2" && { [ -f "$file" ] || mv "$file.part" "$file"; }
  local got; got=$(sha256 "$file")
  if [ "$got" != "$3" ]; then
    echo "checksum mismatch for $1: expected $3, got $got" >&2
    return 1
  fi
}
if [ "$gpl" = 1 ]; then
  fetch "x264-$X264_VERSION.tar.bz2"             "$X264_URL"    "$X264_SHA256"
  fetch "x265_$X265_VERSION.tar.gz"              "$X265_URL"    "$X265_SHA256"
fi
fetch "SVT-AV1-$SVTAV1_VERSION.tar.gz"           "$SVTAV1_URL"  "$SVTAV1_SHA256"
fetch "libvpx-$VPX_VERSION.tar.gz"               "$VPX_URL"     "$VPX_SHA256"
fetch "opus-$OPUS_VERSION.tar.gz"                "$OPUS_URL"    "$OPUS_SHA256"
fetch "lame-$LAME_VERSION.tar.gz"                "$LAME_URL"    "$LAME_SHA256"
fetch "nv-codec-headers-$NVCODEC_VERSION.tar.gz" "$NVCODEC_URL" "$NVCODEC_SHA256"
fetch "zlib-$ZLIB_VERSION.tar.gz"                "$ZLIB_URL"     "$ZLIB_SHA256"
fetch "freetype-$FREETYPE_VERSION.tar.xz"        "$FREETYPE_URL" "$FREETYPE_SHA256"
fetch "fribidi-$FRIBIDI_VERSION.tar.xz"          "$FRIBIDI_URL"  "$FRIBIDI_SHA256"
fetch "harfbuzz-$HARFBUZZ_VERSION.tar.xz"        "$HARFBUZZ_URL" "$HARFBUZZ_SHA256"
fetch "libass-$LIBASS_VERSION.tar.xz"            "$LIBASS_URL"   "$LIBASS_SHA256"
fetch "whisper-$WHISPER_VERSION.tar.gz"          "$WHISPER_URL"  "$WHISPER_SHA256"
case "$target" in
  x86_64-unknown-linux-gnu|x86_64-pc-windows-gnu)
    fetch "vulkansdk-linux-x86_64-$VULKAN_SDK_VERSION.tar.xz" "$VULKAN_SDK_URL" "$VULKAN_SDK_SHA256" ;;
esac
if [ "$target" = x86_64-pc-windows-gnu ]; then
  fetch "VulkanRT-X64-$VULKAN_SDK_VERSION-Components.zip" "$VULKAN_RT_URL" "$VULKAN_RT_SHA256"
fi
echo "all sources verified"

unpack() { # archive -> prints the extracted top directory
  local dir="$work/$(basename "$1" | sed -E 's/\.tar\.(gz|bz2|xz)$//')"
  rm -rf "$dir" && mkdir -p "$dir"
  tar xf "$1" -C "$dir" --strip-components=1
  echo "$dir"
}
host_flag() { [ -n "$cross_host" ] && echo "--host=$cross_host" || true; }

# --- builds ------------------------------------------------------------------
( cd "$(unpack "$dl/nv-codec-headers-$NVCODEC_VERSION.tar.gz")" && make PREFIX="$prefix" install >/dev/null )

if [ "$gpl" = 1 ]; then
( cd "$(unpack "$dl/x264-$X264_VERSION.tar.bz2")"
  ./configure --prefix="$prefix" --enable-static --enable-pic --disable-cli --disable-opencl \
    ${x264_host:+--host=$x264_host} ${cross_host:+--cross-prefix=$(x=${CC%-posix}; echo "${x%gcc}")}
  make -j"$jobs" && make install )

# x265 builds with -ffast-math, which makes glibc's headers route math calls
# to libmvec; undefining __FAST_MATH__ keeps the fast code without that extra
# runtime dependency.
( src="$(unpack "$dl/x265_$X265_VERSION.tar.gz")"
  # CMake 4 refuses the OLD behaviour x265 asks for; with NEW, Apple's compiler
  # reports itself as AppleClang, so match it as a Clang too.
  sed -i.bak -e 's/cmake_policy(SET CMP0025 OLD)/cmake_policy(SET CMP0025 NEW)/' \
    -e 's/cmake_policy(SET CMP0054 OLD)/cmake_policy(SET CMP0054 NEW)/' \
    -e 's/if(${CMAKE_CXX_COMPILER_ID} STREQUAL "Clang")/if(${CMAKE_CXX_COMPILER_ID} MATCHES "Clang")/' \
    "$src/source/CMakeLists.txt"
  CXXFLAGS="${CXXFLAGS:-} -U__FAST_MATH__" cmake -S "$src/source" -B "$src/out" -G Ninja ${cmake_extra[@]+"${cmake_extra[@]}"} \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$prefix" -DCMAKE_POSITION_INDEPENDENT_CODE=ON \
    -DENABLE_SHARED=OFF -DENABLE_CLI=OFF -DCMAKE_POLICY_VERSION_MINIMUM=3.5
  cmake --build "$src/out" -j "$jobs" && cmake --install "$src/out" )
fi

( src="$(unpack "$dl/SVT-AV1-$SVTAV1_VERSION.tar.gz")"
  cmake -S "$src" -B "$src/out" -G Ninja ${cmake_extra[@]+"${cmake_extra[@]}"} \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$prefix" -DCMAKE_INSTALL_LIBDIR=lib \
    -DCMAKE_POSITION_INDEPENDENT_CODE=ON -DBUILD_SHARED_LIBS=OFF -DBUILD_APPS=OFF -DBUILD_DEC=OFF -DBUILD_TESTING=OFF
  cmake --build "$src/out" -j "$jobs" && cmake --install "$src/out" )

( cd "$(unpack "$dl/libvpx-$VPX_VERSION.tar.gz")"
  CROSS="$vpx_cross" ./configure --prefix="$prefix" --target="$vpx_target" --enable-pic --enable-vp9-highbitdepth \
    --disable-examples --disable-tools --disable-docs --disable-unit-tests --enable-static --disable-shared
  make -j"$jobs" && make install )

( cd "$(unpack "$dl/opus-$OPUS_VERSION.tar.gz")"
  CFLAGS="${CFLAGS:-} $opus_cflags" ./configure --prefix="$prefix" $(host_flag) --enable-static --disable-shared --with-pic --disable-doc --disable-extra-programs $opus_extra
  make -j"$jobs" && make install )

( cd "$(unpack "$dl/lame-$LAME_VERSION.tar.gz")"
  # lame 3.100 exports a symbol that no longer exists; drop it from the export list.
  sed -i.bak '/lame_init_old/d' include/libmp3lame.sym
  ./configure --prefix="$prefix" $(host_flag) --enable-static --disable-shared --with-pic \
    --disable-frontend --disable-gtktest --disable-decoder
  make -j"$jobs" && make install )

# --- the text stack -----------------------------------------------------------
# zlib: FFmpeg's PNG decoder. Its configure does not know MinGW; the Makefile
# made for it does.
( cd "$(unpack "$dl/zlib-$ZLIB_VERSION.tar.gz")"
  if [ "$target" = x86_64-pc-windows-gnu ]; then
    # install also builds the DLL (it needs the prefixed windres) but, with
    # SHARED_MODE=0, copies only the static library, the headers and zlib.pc.
    make -f win32/Makefile.gcc PREFIX=x86_64-w64-mingw32- SHARED_MODE=0 -j"$jobs" \
      BINARY_PATH="$prefix/bin" INCLUDE_PATH="$prefix/include" LIBRARY_PATH="$prefix/lib" install
  else
    CFLAGS="${CFLAGS:-} -fPIC -O2" ./configure --prefix="$prefix" --static
    make -j"$jobs" && make install
  fi )

# FreeType: glyphs for drawtext and libass; only plain TrueType/OpenType fonts.
( cd "$(unpack "$dl/freetype-$FREETYPE_VERSION.tar.xz")"
  ./configure --prefix="$prefix" $(host_flag) --enable-static --disable-shared --with-pic \
    --without-zlib --without-bzip2 --without-png --without-brotli --without-harfbuzz
  make -j"$jobs" && make install )

# FriBidi: right-to-left order for Persian, Arabic and Hebrew.
( cd "$(unpack "$dl/fribidi-$FRIBIDI_VERSION.tar.xz")"
  ./configure --prefix="$prefix" $(host_flag) --enable-static --disable-shared --with-pic
  make -j"$jobs" && make install )

# HarfBuzz: joins and shapes the letters; through CMake like x265, so no meson.
( src="$(unpack "$dl/harfbuzz-$HARFBUZZ_VERSION.tar.xz")"
  cmake -S "$src" -B "$src/out" -G Ninja ${cmake_extra[@]+"${cmake_extra[@]}"} \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$prefix" -DCMAKE_INSTALL_LIBDIR=lib \
    -DCMAKE_PREFIX_PATH="$prefix" -DCMAKE_POSITION_INDEPENDENT_CODE=ON -DBUILD_SHARED_LIBS=OFF \
    -DHB_HAVE_FREETYPE=ON -DHB_HAVE_GLIB=OFF -DHB_HAVE_ICU=OFF -DHB_HAVE_GOBJECT=OFF \
    -DHB_BUILD_SUBSET=OFF -DHB_BUILD_UTILS=OFF -DHB_BUILD_TESTS=OFF
  cmake --build "$src/out" -j "$jobs" && cmake --install "$src/out" )

# libass: the subtitles filter. No fontconfig: fonts come from the fontsdir the
# app passes (its bundled font), or DirectWrite on Windows and CoreText on macOS.
( cd "$(unpack "$dl/libass-$LIBASS_VERSION.tar.xz")"
  ./configure --prefix="$prefix" $(host_flag) --enable-static --disable-shared --with-pic \
    --disable-fontconfig --disable-require-system-font-provider --disable-libunibreak
  make -j"$jobs" && make install )

# --- speech to text ----------------------------------------------------------
# whisper.cpp and its ggml: no OpenMP (its runtime would be one more library
# to ship) and no -march=native (the bundle runs on other machines than the
# one that built it). On Apple silicon the graphics card listens through
# Metal, its shaders built into the library and compiled when first used;
# both Macs use Accelerate on the CPU. On Linux and Windows it listens
# through Vulkan (NVIDIA, AMD and Intel cards), its shaders compiled here by
# the SDK's glslc (on the Linux build machine for both); the bundle ships the
# Vulkan loader, so FFmpeg starts on a machine without Vulkan, where ggml
# finds no device and whisper uses the CPU.
vulkan_gpu=() vulkan_link=""
case "$target" in
  x86_64-unknown-linux-gnu|x86_64-pc-windows-gnu)
    vk="$work/vulkan-sdk"
    rm -rf "$vk" && mkdir -p "$vk"
    tar xJf "$dl/vulkansdk-linux-x86_64-$VULKAN_SDK_VERSION.tar.xz" -C "$vk" --strip-components=2 --wildcards \
      "$VULKAN_SDK_VERSION/x86_64/bin/glslc" "$VULKAN_SDK_VERSION/x86_64/include/vulkan" \
      "$VULKAN_SDK_VERSION/x86_64/include/vk_video" "$VULKAN_SDK_VERSION/x86_64/lib/libvulkan.so*" ;;
esac
case "$target" in
  x86_64-unknown-linux-gnu)
    cp -P "$vk"/lib/libvulkan.so* "$prefix/lib/"
    vulkan_lib="$prefix/lib/libvulkan.so" vulkan_link=-lvulkan ;;
  x86_64-pc-windows-gnu)
    # vulkan-1.dll from the Vulkan runtime, and a MinGW import library for
    # it made from the functions it exports.
    rm -rf "$work/vulkan-rt" && mkdir -p "$work/vulkan-rt" "$prefix/bin"
    unzip -q -o "$dl/VulkanRT-X64-$VULKAN_SDK_VERSION-Components.zip" '*/x64/vulkan-1.dll' -d "$work/vulkan-rt"
    cp "$work"/vulkan-rt/*/x64/vulkan-1.dll "$prefix/bin/"
    { echo "LIBRARY vulkan-1.dll"; echo "EXPORTS"
      x86_64-w64-mingw32-objdump -p "$prefix/bin/vulkan-1.dll" |
        sed -n '/\[Ordinal\/Name Pointer\] Table/,/^$/p' | grep -oE '\bvk[A-Za-z0-9_]+'
    } > "$work/vulkan-1.def"
    x86_64-w64-mingw32-dlltool -d "$work/vulkan-1.def" -D vulkan-1.dll -l "$prefix/lib/libvulkan-1.dll.a"
    vulkan_lib="$prefix/lib/libvulkan-1.dll.a" vulkan_link=-lvulkan-1 ;;
esac
if [ -n "$vulkan_link" ]; then
  vulkan_gpu=(-DGGML_VULKAN=ON -DVulkan_INCLUDE_DIR="$vk/include" -DVulkan_LIBRARY="$vulkan_lib"
              -DVulkan_GLSLC_EXECUTABLE="$vk/bin/glslc")
fi
case "$target" in
  aarch64-apple-darwin)
    whisper_gpu=(-DGGML_METAL=ON -DGGML_METAL_EMBED_LIBRARY=ON -DGGML_ACCELERATE=ON)
    whisper_libs="-lggml-metal"
    # ggml-metal is Objective-C: the runtime (-lobjc) comes too.
    whisper_frameworks="-lobjc -Wl,-framework,Foundation -Wl,-framework,Metal -Wl,-framework,MetalKit -Wl,-framework,Accelerate" ;;
  x86_64-apple-darwin)
    whisper_gpu=(-DGGML_METAL=OFF -DGGML_ACCELERATE=ON)
    whisper_libs=""
    whisper_frameworks="-Wl,-framework,Accelerate" ;;
  *)
    whisper_gpu=(-DGGML_METAL=OFF -DGGML_ACCELERATE=OFF)
    whisper_libs=""
    whisper_frameworks="" ;;
esac
if [ ${#vulkan_gpu[@]} -gt 0 ]; then
  whisper_gpu+=("${vulkan_gpu[@]}")
  whisper_libs="-lggml-vulkan"
  whisper_frameworks="$vulkan_link"
else
  whisper_gpu+=(-DGGML_VULKAN=OFF)
fi
# On x86-64 the CPU code needs AVX2 and FMA (every x86-64 machine since
# about 2013), set explicitly: ggml turns them off by itself when it is
# cross-compiled, which would make Windows and Intel Mac captions slow.
case "$target" in x86_64-*) whisper_cpu=(-DGGML_SSE42=ON -DGGML_AVX=ON -DGGML_AVX2=ON -DGGML_FMA=ON -DGGML_F16C=ON -DGGML_BMI2=ON) ;; *) whisper_cpu=() ;; esac
# Ubuntu 22.04's MinGW-w64 headers do not have Windows 8's thread power
# throttling API, which ggml uses only for Windows 8 and later: build it as
# for Windows 7, where ggml leaves that call out.
[ "$target" = x86_64-pc-windows-gnu ] && whisper_cpu+=(-DCMAKE_C_FLAGS="${CFLAGS:-} -D_WIN32_WINNT=0x0601" -DCMAKE_CXX_FLAGS="${CXXFLAGS:-} -D_WIN32_WINNT=0x0601")
( src="$(unpack "$dl/whisper-$WHISPER_VERSION.tar.gz")/whisper.cpp"
  cmake -S "$src" -B "$src/out" -G Ninja ${cmake_extra[@]+"${cmake_extra[@]}"} ${whisper_cpu[@]+"${whisper_cpu[@]}"} "${whisper_gpu[@]}" \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$prefix" -DCMAKE_INSTALL_LIBDIR=lib \
    -DCMAKE_POSITION_INDEPENDENT_CODE=ON -DBUILD_SHARED_LIBS=OFF \
    -DWHISPER_BUILD_EXAMPLES=OFF -DWHISPER_BUILD_TESTS=OFF -DWHISPER_BUILD_SERVER=OFF \
    -DGGML_NATIVE=OFF -DGGML_OPENMP=OFF -DGGML_BLAS=OFF \
    -DGGML_CUDA=OFF -DGGML_BACKEND_DL=OFF
  cmake --build "$src/out" -j "$jobs" && cmake --install "$src/out"
  # On Windows ggml names its libraries without the lib prefix (ggml.a),
  # and the MinGW linker finds -lggml only as libggml.a.
  for lib in whisper ggml ggml-cpu ggml-metal ggml-vulkan ggml-base; do
    if [ -f "$prefix/lib/$lib.a" ]; then mv "$prefix/lib/$lib.a" "$prefix/lib/lib$lib.a"; fi
  done
  # whisper.cpp's own whisper.pc lists ggml before whisper and leaves out
  # ggml-cpu, ggml-metal, the frameworks and the C++ runtime, which static
  # linking needs, in this order. The frameworks are one word each
  # (-Wl,-framework,Metal), so pkg-config cannot fold the -framework pairs.
  case "$target" in *-apple-darwin) cxx=-lc++ ;; *) cxx=-lstdc++ ;; esac
  cat > "$prefix/lib/pkgconfig/whisper.pc" <<PC
prefix=$prefix
libdir=\${prefix}/lib
includedir=\${prefix}/include

Name: whisper
Description: whisper.cpp speech to text, static
Version: $WHISPER_VERSION
Libs: -L\${libdir} -lwhisper -lggml -lggml-cpu${whisper_libs:+ $whisper_libs} -lggml-base
Libs.private: $cxx -lm -lpthread${whisper_frameworks:+ $whisper_frameworks}
Cflags: -I\${includedir}
PC
)

if [ "$target" = x86_64-pc-windows-gnu ]; then
  # The DLLs must not need the MinGW runtime DLLs (libwinpthread-1, libstdc++-6,
  # libgcc_s_seh-1), which Windows does not have. Static copies placed in
  # <prefix>/lib are found before the import libraries in the toolchain's
  # directories, and x265's pkg-config file must not ask for libgcc_s.
  cp "$($CC -print-file-name=libwinpthread.a)" "$prefix/lib/libpthread.a"
  cp "$($CC -print-file-name=libwinpthread.a)" "$prefix/lib/libwinpthread.a"
  cp "$($CXX -print-file-name=libstdc++.a)" "$prefix/lib/libstdc++.a"
  if [ -f "$prefix/lib/pkgconfig/x265.pc" ]; then
    sed -i.bak 's/ -lgcc_s//g' "$prefix/lib/pkgconfig/x265.pc"
  fi
fi

# VAAPI (Linux: Intel and AMD cards). FFmpeg links libva directly, and a
# bundle linked so would not start where libva is not installed; a libva
# shipped in the bundle could not load the system's newer drivers. So FFmpeg
# is compiled against the build machine's libva headers (Ubuntu 22.04's, the
# oldest system the bundle runs on: what it uses of libva, every newer one
# has too) and linked with stand-ins that open the system's libva.so.2 and
# libva-drm.so.2 when a VAAPI device is first asked for (lazylib.sh). Where
# libva-drm is not installed its one function, which hands out the device,
# returns NULL: FFmpeg then says there is no such device and goes on.
if [ "$target" = x86_64-unknown-linux-gnu ]; then
  # The system's own libva, not what this prefix may hold from an earlier run.
  system_va() { env -u PKG_CONFIG_PATH pkg-config "$@"; }
  system_va --exists libva libva-drm ||
    { echo "the VAAPI headers and libraries are missing: install libva-dev" >&2; exit 1; }
  va_include=$(system_va --variable=includedir libva)
  va_libdir=$(system_va --variable=libdir libva)
  mkdir -p "$prefix/include" "$prefix/lib/pkgconfig"
  rm -rf "$prefix/include/va" && cp -R "$va_include/va" "$prefix/include/va"
  "$here/lazylib.sh" "$va_libdir/libva.so.2" "$prefix/lib/libva.a"
  "$here/lazylib.sh" --absent=null "$va_libdir/libva-drm.so.2" "$prefix/lib/libva-drm.a"
  for va in libva libva-drm; do
    cat > "$prefix/lib/pkgconfig/$va.pc" <<PC
Name: $va
Description: VA-API, the system's, opened when a VAAPI device is first asked for
Version: $(system_va --modversion "$va")
Libs: -L$prefix/lib -l${va#lib} -ldl
Cflags: -I$prefix/include
PC
  done
fi

echo "codec libraries installed in $prefix"
