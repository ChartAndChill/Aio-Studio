#!/usr/bin/env bash
# Builds the minimal FFmpeg bundle the app ships: ffmpeg, ffprobe and their
# shared libav*/libsw* libraries, with the codec libraries from deps.sh linked
# in statically, NVENC through the dlopen'ed driver, on Linux VAAPI through
# the system's libva (opened when first used), and no other system
# library pulled in. The result lands flat in dist/ffmpeg/<target>/ with an
# $ORIGIN rpath, ready to be copied next to the app.
#
#   packaging/ffmpeg/build.sh <target>
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
root="$(cd "$here/../.." && pwd)"
target=${1:?usage: build.sh <target>}
# shellcheck source=versions.env
source "$here/versions.env"
# shellcheck source=license.sh
source "$here/license.sh"

deps="$root/dist/deps/$target"
out="$root/dist/ffmpeg/$target"
dl=${AIO_DL_CACHE:-$root/dist/deps/dl}
work="$root/dist/deps/build"
jobs=${JOBS:-$(getconf _NPROCESSORS_ONLN 2>/dev/null || sysctl -n hw.ncpu)}

# Opus is built for every target, x264 only for the GPL one.
if [ "${AIO_REBUILD_DEPS:-0}" = 1 ] || [ ! -f "$deps/lib/pkgconfig/opus.pc" ]; then
  AIO_DL_CACHE="$dl" AIO_BUILD_DIR="$work" "$here/deps.sh" "$target" "$deps"
fi

mkdir -p "$dl" "$work"
archive="$dl/ffmpeg-$FFMPEG_VERSION.tar.xz"
[ -f "$archive" ] || curl -fsSL --retry 6 --retry-delay 10 --retry-all-errors -o "$archive" "$FFMPEG_URL"
sum=$( (command -v sha256sum >/dev/null && sha256sum "$archive") || shasum -a 256 "$archive"); sum=${sum%% *}
[ "$sum" = "$FFMPEG_SHA256" ] || { echo "checksum mismatch for $archive: $sum" >&2; exit 1; }

src="$work/ffmpeg-$FFMPEG_VERSION"
rm -rf "$src" && mkdir -p "$src" && tar xf "$archive" -C "$src" --strip-components=1
stage="$work/ffmpeg-stage-$target"
rm -rf "$stage"

cross=()
case "$target" in
  # configure evaluates this once and make once more; the escaped, quoted form
  # survives both and reaches the linker as a literal $ORIGIN.
  x86_64-unknown-linux-gnu) rpath="-Wl,-rpath,'\\\$\\\$ORIGIN'" ;;
  # The dylibs are found next to the program through @rpath, not at the
  # absolute staging path they were installed to.
  aarch64-apple-darwin)     rpath='-Wl,-rpath,@loader_path'
                            cross=(--install-name-dir=@rpath) ;;
  x86_64-apple-darwin)      rpath='-Wl,-rpath,@loader_path'
                            cross=(--install-name-dir=@rpath --enable-cross-compile --arch=x86_64 --target-os=darwin --extra-cflags=-arch\ x86_64 --extra-ldflags=-arch\ x86_64) ;;
  x86_64-pc-windows-gnu)    rpath='-static-libgcc'
                            # The posix thread model, as deps.sh builds the libraries with.
                            cross=(--enable-cross-compile --arch=x86_64 --target-os=mingw32 --cross-prefix=x86_64-w64-mingw32-
                                   --cc=x86_64-w64-mingw32-gcc-posix --cxx=x86_64-w64-mingw32-g++-posix
                                   --pkg-config=pkg-config) ;;  # not x86_64-w64-mingw32-pkg-config
  *) echo "unsupported target: $target" >&2; exit 2 ;;
esac

# Hardware encoding: NVENC (headers only, the driver is loaded at run time) on
# Linux and Windows; on Linux also VAAPI, for Intel and AMD cards, through the
# system's libva (deps.sh: opened when first used, so the bundle starts
# without it); VideoToolbox, a system framework, on macOS.
case "$target" in
  *-apple-darwin) hw_flags=(--enable-videotoolbox) hw_encoders=h264_videotoolbox,hevc_videotoolbox ;;
  *-linux-*)      hw_flags=(--enable-ffnvcodec --enable-nvenc --enable-vaapi)
                  hw_encoders=h264_nvenc,hevc_nvenc,av1_nvenc,h264_vaapi,hevc_vaapi ;;
  *)              hw_flags=(--enable-ffnvcodec --enable-nvenc) hw_encoders=h264_nvenc,hevc_nvenc,av1_nvenc ;;
esac

# GPL on Linux (x264, x265), LGPL on macOS and Windows (see license.sh).
licensed=$(license_encoders "$target")
# (A loop, not mapfile: macOS's own bash is 3.2.)
license_configure=()
while read -r flag; do
  [ -n "$flag" ] && license_configure+=("$flag")
done < <(license_flags "$target")
encoders=${licensed:+$licensed,}libsvtav1,libvpx_vp8,libvpx_vp9,$hw_encoders
encoders+=,aac,libopus,libmp3lame,flac,alac,pcm_s16le,ac3,mpeg4,prores_ks,gif,mjpeg,wrapped_avframe
# DNxHR HQ, the hand-off format of Avid and broadcast (the "DNxHR HQ" preset).
encoders+=,dnxhd
# Raw RGBA frames and PCM on a pipe: thumbnails and the player read these.
encoders+=,rawvideo
# Stills and subtitles: PNG frames, and subtitles kept as a stream in MP4
# (mov_text), Matroska (srt, ass) and WebM (webvtt), or written as files.
encoders+=,png,movtext,srt,ass,subrip,webvtt
muxers=mp4,mov,ipod,matroska,webm,avi,mpegts,gif,mp3,ogg,opus,flac,wav,adts,ac3,null,image2,ffmetadata,rawvideo,pcm_s16le
muxers+=,srt,ass,webvtt

# HarfBuzz is C++: its static library needs the C++ runtime at link time.
case "$target" in
  *-apple-darwin) cxx_lib=-lc++ ;;
  *)              cxx_lib=-lstdc++ ;;
esac

cd "$src"
PKG_CONFIG_PATH="$deps/lib/pkgconfig" ./configure \
  --prefix="$stage" ${cross[@]+"${cross[@]}"} \
  ${license_configure[@]+"${license_configure[@]}"} --enable-shared --disable-static \
  --disable-doc --disable-network --disable-debug --disable-autodetect \
  --disable-programs --disable-ffplay --enable-ffmpeg --enable-ffprobe \
  --disable-indevs --enable-indev=lavfi --disable-outdevs \
  --disable-encoders --enable-encoder="$encoders" \
  --disable-muxers --enable-muxer="$muxers" \
  --enable-libsvtav1 --enable-libvpx --enable-libopus --enable-libmp3lame \
  --enable-zlib --enable-libfreetype --enable-libfribidi --enable-libharfbuzz --enable-libass \
  --enable-whisper \
  "${hw_flags[@]}" \
  --pkg-config-flags=--static \
  --extra-cflags="-I$deps/include" \
  --extra-ldflags="-L$deps/lib $rpath" \
  --extra-libs="-lpthread -lm $cxx_lib"
make -j"$jobs"
make install

# Flat bundle: programs and shared libraries side by side. Each library is
# copied once, as a real file under the name the programs load it by
# (libavcodec.so.62, libavcodec.62.dylib); the development symlinks and fully
# versioned names would only triple the size of the installers.
rm -rf "$out" && mkdir -p "$out"
cp -P "$stage"/bin/ffmpeg* "$stage"/bin/ffprobe* "$out/"
if [ "$target" = x86_64-pc-windows-gnu ]; then
  cp "$stage"/bin/*.dll "$out/"
  # The Vulkan loader whisper.cpp's Vulkan backend links: shipped, so
  # ffmpeg.exe starts where Windows has none (whisper then uses the CPU).
  cp "$deps/bin/vulkan-1.dll" "$out/"
else
  for lib in "$stage"/lib/lib*; do
    case "$(basename "$lib")" in
      lib*.so.[0-9]*.*|lib*.[0-9]*.[0-9]*.dylib) ;;          # fully versioned names
      lib*.so.[0-9]*|lib*.[0-9]*.dylib) cp -L "$lib" "$out/" ;;  # the load names
    esac
  done
fi
if [ "$target" = x86_64-unknown-linux-gnu ]; then
  # The Vulkan loader whisper.cpp's Vulkan backend links: shipped, so FFmpeg
  # starts where the system has none (whisper then listens on the CPU).
  cp -L "$deps/lib/libvulkan.so.1" "$out/"
  # make expands the shared libraries' link flags once more than the
  # programs', which leaves them with RUNPATH "RIGIN"; give every file in the
  # bundle the same $ORIGIN so each library finds its siblings on its own.
  for f in "$out"/ffmpeg "$out"/ffprobe "$out"/lib*.so.*; do
    patchelf --set-rpath '$ORIGIN' "$f"
  done
fi
echo "FFmpeg $FFMPEG_VERSION for $target installed in $out"
