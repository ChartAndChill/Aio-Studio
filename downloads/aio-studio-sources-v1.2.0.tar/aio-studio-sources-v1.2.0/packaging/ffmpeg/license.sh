# The licence each target's FFmpeg is under, and what follows from it.
# Sourced by build.sh and deps.sh.
#
# Linux: GPL, with x264 and x265, the best H.264 and HEVC encoders; the app
# is free there. macOS and Windows: LGPL, so the app can be sold there: no
# x264 or x265; H.264 and HEVC come from the system (VideoToolbox on macOS,
# Media Foundation on Windows) and the graphics card.

# gpl or lgpl.
ffmpeg_license() {
  case "$1" in
    *-linux-*) echo gpl ;;
    *) echo lgpl ;;
  esac
}

# The configure flags that follow from the licence (one a line).
license_flags() {
  if [ "$(ffmpeg_license "$1")" = gpl ]; then
    printf '%s\n' --enable-gpl --enable-libx264 --enable-libx265
  fi
  case "$1" in
    # Windows' own H.264 and HEVC encoders; --disable-autodetect would
    # leave them out. FFmpeg 8's mfenc.c takes Direct3D 11 frames too and
    # needs the d3d11va header for IID_ID3D11Texture2D (d3d11.dll is loaded
    # when used, so nothing new is linked).
    *-windows-*) printf '%s\n' --enable-mediafoundation --enable-d3d11va ;;
  esac
}

# The encoders, comma separated, that follow from the licence.
license_encoders() {
  if [ "$(ffmpeg_license "$1")" = gpl ]; then
    echo libx264,libx265
  else
    case "$1" in
      *-windows-*) echo h264_mf,hevc_mf ;;
      # VideoToolbox's are among build.sh's hardware encoders.
      *) echo "" ;;
    esac
  fi
}
