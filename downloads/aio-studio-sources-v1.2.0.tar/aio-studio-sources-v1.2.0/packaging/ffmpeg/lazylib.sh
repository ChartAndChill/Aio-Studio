#!/usr/bin/env bash
# Makes a static stand-in for a shared library of the system, so that a
# program can use the library where it is installed and still starts where
# it is not. Every function of the library gets a small stub of the same
# name; the first call of any of them opens the library (by its soname, with
# dlopen) and from then on the stubs jump straight to the real functions.
#
#   packaging/ffmpeg/lazylib.sh [--absent=exit|null] <library.so.N> <out.a>
#
# What a call does where the library is not installed:
#   --absent=exit  (default) says so on stderr and ends the program with 1;
#   --absent=null  returns 0 (NULL): for a library whose functions hand out
#                  objects, so that the caller sees "there is none".
# A library that is there but lacks the function (an older one) always ends
# the program with 1, naming the function.
#
# The stubs are hidden: a shared library linked with the stand-in does not
# export them. x86-64 Linux only (System V calling convention, ELF).
set -euo pipefail

absent=exit
case "${1:-}" in
  --absent=exit|--absent=null) absent=${1#--absent=}; shift ;;
esac
lib=${1:?usage: lazylib.sh [--absent=exit|null] <library.so.N> <out.a>}
out=${2:?usage: lazylib.sh [--absent=exit|null] <library.so.N> <out.a>}
[ -f "$lib" ] || { echo "lazylib: no such library: $lib" >&2; exit 2; }
[ "$(uname -s)-$(uname -m)" = Linux-x86_64 ] || { echo "lazylib: x86-64 Linux only" >&2; exit 2; }

soname=$(readelf -d "$lib" | sed -n 's/.*(SONAME).*\[\(.*\)\]/\1/p')
[ -n "$soname" ] || { echo "lazylib: $lib has no soname" >&2; exit 2; }
# The library's functions: defined, dynamic, code (T), weak (W) or picked at
# load time (i); without the version a symbol may carry (name@@VERSION).
names=$(nm -D --defined-only "$lib" | awk '$2 ~ /^[TWi]$/ { sub(/@.*/, "", $3); print $3 }' | LC_ALL=C sort -u)
[ -n "$names" ] || { echo "lazylib: $lib exports no function" >&2; exit 2; }
count=$(wc -l <<<"$names")
# One name space per library, so that two stand-ins fit in one program.
tag=$(tr -c 'A-Za-z0-9\n' '_' <<<"$soname")

tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT

{
  cat <<EOF
/* Stand-in for $soname, made by packaging/ffmpeg/lazylib.sh. */
	.text
	.hidden	aio_lazy_${tag}_resolve
/* The first call of a function: every register an argument may be in
   (rdi to r9, xmm0 to xmm7, and rax, which counts the vector registers of
   a variadic call) is kept, the function is looked up, and the call goes
   on to it. On entry the stack holds the function's number and, above it,
   the caller's return address; with the seven registers and 136 bytes
   more it is aligned to 16 for the call. */
	.type	aio_lazy_${tag}_first, @function
aio_lazy_${tag}_first:
	pushq	%rdi
	pushq	%rsi
	pushq	%rdx
	pushq	%rcx
	pushq	%r8
	pushq	%r9
	pushq	%rax
	subq	\$136, %rsp
	movdqu	%xmm0, 0(%rsp)
	movdqu	%xmm1, 16(%rsp)
	movdqu	%xmm2, 32(%rsp)
	movdqu	%xmm3, 48(%rsp)
	movdqu	%xmm4, 64(%rsp)
	movdqu	%xmm5, 80(%rsp)
	movdqu	%xmm6, 96(%rsp)
	movdqu	%xmm7, 112(%rsp)
	movq	192(%rsp), %rdi
	call	aio_lazy_${tag}_resolve
	movq	%rax, %r11
	movdqu	0(%rsp), %xmm0
	movdqu	16(%rsp), %xmm1
	movdqu	32(%rsp), %xmm2
	movdqu	48(%rsp), %xmm3
	movdqu	64(%rsp), %xmm4
	movdqu	80(%rsp), %xmm5
	movdqu	96(%rsp), %xmm6
	movdqu	112(%rsp), %xmm7
	addq	\$136, %rsp
	popq	%rax
	popq	%r9
	popq	%r8
	popq	%rcx
	popq	%rdx
	popq	%rsi
	popq	%rdi
	addq	\$8, %rsp
	jmp	*%r11
	.size	aio_lazy_${tag}_first, .-aio_lazy_${tag}_first
EOF
  i=0
  while read -r name; do
    cat <<EOF
	.globl	$name
	.hidden	$name
	.type	$name, @function
$name:
	endbr64
	jmp	*aio_lazy_${tag}_table+$((8 * i))(%rip)
	.size	$name, .-$name
.Lfirst$i:
	pushq	\$$i
	jmp	aio_lazy_${tag}_first
EOF
    i=$((i + 1))
  done <<<"$names"
  cat <<EOF
/* Where each stub jumps: to the lookup at first, to the function after. */
	.data
	.balign	8
	.globl	aio_lazy_${tag}_table
	.hidden	aio_lazy_${tag}_table
	.type	aio_lazy_${tag}_table, @object
aio_lazy_${tag}_table:
EOF
  for ((i = 0; i < count; i++)); do printf '\t.quad\t.Lfirst%d\n' "$i"; done
  cat <<EOF
	.size	aio_lazy_${tag}_table, .-aio_lazy_${tag}_table
	.section	.note.GNU-stack,"",@progbits
EOF
} > "$tmp/stubs.S"

{
  cat <<EOF
/* Stand-in for $soname, made by packaging/ffmpeg/lazylib.sh. */
#include <dlfcn.h>
#include <stdio.h>
#include <unistd.h>

extern void *aio_lazy_${tag}_table[] __attribute__((visibility("hidden")));

static const char *const names[] = {
EOF
  sed 's/.*/    "&",/' <<<"$names"
  cat <<EOF
};

/* What a function of a library that is not here does: nothing, and 0. */
static long not_here(void) { return 0; }

/* The function with the number \`index\`, looked up in the library, which is
   opened the first time. Two threads may get here at once: both open the
   library (it counts how often) and both write the same address. */
__attribute__((visibility("hidden")))
void *aio_lazy_${tag}_resolve(unsigned long index)
{
    static void *volatile library;
    static volatile int absent;
    void *lib = library;
    void *found;

    if (!lib && !absent) {
        lib = dlopen("$soname", RTLD_LAZY | RTLD_GLOBAL);
        if (lib)
            library = lib;
        else
            absent = 1;
    }
    if (!lib) {
EOF
  if [ "$absent" = null ]; then
    echo '        found = (void *)not_here;'
  else
    cat <<EOF
        fprintf(stderr, "$soname is not installed on this system (wanted for %s)\n", names[index]);
        _exit(1);
EOF
  fi
  cat <<EOF
    } else {
        found = dlsym(lib, names[index]);
        if (!found) {
            fprintf(stderr, "$soname on this system has no %s: it is too old\n", names[index]);
            _exit(1);
        }
    }
    aio_lazy_${tag}_table[index] = found;
#ifdef AIO_LAZY_SCRUB
    /* For the check: the lookup may use every register an argument travels
       in; here it does, so that one left unsaved shows. */
    __asm__ volatile(
        "pcmpeqd %%xmm0, %%xmm0; pcmpeqd %%xmm1, %%xmm1; pcmpeqd %%xmm2, %%xmm2; pcmpeqd %%xmm3, %%xmm3;"
        "pcmpeqd %%xmm4, %%xmm4; pcmpeqd %%xmm5, %%xmm5; pcmpeqd %%xmm6, %%xmm6; pcmpeqd %%xmm7, %%xmm7;"
        "movq \$-1, %%rdi; movq \$-1, %%rsi; movq \$-1, %%rdx; movq \$-1, %%rcx; movq \$-1, %%r8; movq \$-1, %%r9"
        : : : "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7", "rdi", "rsi", "rdx", "rcx", "r8", "r9");
#endif
    return found;
}
EOF
  # Without a use, the helper of the other mode would be a warning.
  [ "$absent" = null ] || echo 'static void *const unused_not_here __attribute__((unused)) = (void *)not_here;'
} > "$tmp/resolve.c"

cc=${CC:-cc}
# AIO_LAZYLIB_SCRUB=1 (packaging/checks/lazylib.sh sets it) makes the lookup
# dirty every argument register, as dlopen and dlsym are free to.
scrub=()
[ "${AIO_LAZYLIB_SCRUB:-0}" = 1 ] && scrub=(-DAIO_LAZY_SCRUB)
"$cc" -O2 -fPIC -fvisibility=hidden -Wall -Werror ${scrub[@]+"${scrub[@]}"} -c "$tmp/resolve.c" -o "$tmp/resolve.o"
"$cc" -fPIC -Wa,--noexecstack -c "$tmp/stubs.S" -o "$tmp/stubs.o"
mkdir -p "$(dirname "$out")"
rm -f "$out"
"${AR:-ar}" rcs "$out" "$tmp/stubs.o" "$tmp/resolve.o"
echo "lazylib: $out stands in for $soname ($count functions, absent: $absent)"
