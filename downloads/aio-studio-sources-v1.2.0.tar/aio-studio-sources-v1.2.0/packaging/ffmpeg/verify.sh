#!/usr/bin/env bash
# Verifies a minimal FFmpeg bundle before it ships: small enough, and
# self-contained apart from the C/C++ runtime every Linux system has.
#
#   packaging/ffmpeg/verify.sh <dir>
set -uo pipefail
dir=${1:?usage: verify.sh <dir>}
dir=$(cd "$dir" && pwd)
limit=${AIO_FFMPEG_SIZE_LIMIT:-60000000}
fail=0

size=$(du -sb "$dir" | cut -f1)
if [ "$size" -lt "$limit" ]; then
  echo "PASS: size $size bytes (limit $limit)"
else
  echo "FAIL: size $size bytes (limit $limit)"; fail=1
fi

# Libraries that may come from the system; everything else must be in <dir>.
allowed='^(libc|libm|libdl|libpthread|librt|libgcc_s|libstdc\+\+)\.so|^ld-linux|^linux-vdso'
for bin in ffmpeg ffprobe; do
  if [ ! -x "$dir/$bin" ]; then
    echo "FAIL: $bin missing"; fail=1; continue
  fi
  bad=""
  # Each line: "name => path (addr)", "name => not found" or "path (addr)".
  while read -r name arrow path _; do
    [ "$arrow" = "=>" ] || { path=$name; name=$(basename "$name"); }
    case "$path" in
      "$dir"/*) continue ;;
      not) bad+=" $name(not found)"; continue ;;
    esac
    [[ $name =~ $allowed ]] || bad+=" $name($path)"
  done < <(env -i ldd "$dir/$bin")
  if [ -z "$bad" ]; then
    echo "PASS: $bin links only to $dir and the system C/C++ runtime"
  else
    echo "FAIL: $bin links outside the bundle:$bad"; fail=1
  fi
done
exit $fail
