#!/usr/bin/env bash
# Puts the licence texts and notices of one target where the installers
# pick them up: dist/licenses/ (see crates/aio-gui/Cargo.toml). The app is
# under its author's own licence (LICENSE, as AIO-STUDIO.txt): free of
# charge on Linux, paid on macOS and Windows, not open source. Its FFmpeg
# is GPL on Linux (with x264 and x265) and LGPL, without them, elsewhere.
#
#   packaging/stage-licenses.sh <target> [out]   (default out: dist/licenses)
set -euo pipefail
cd "$(dirname "$0")/.."
target=${1:?usage: stage-licenses.sh <target> [out]}
out=${2:-dist/licenses}
# shellcheck source=ffmpeg/license.sh
source packaging/ffmpeg/license.sh
# shellcheck source=ffmpeg/versions.env
source packaging/ffmpeg/versions.env

rm -rf "$out" && mkdir -p "$out"
cp licenses/THIRD-PARTY.md licenses/LGPL-2.1.txt licenses/MPL-2.0.txt "$out/"
cp LICENSE "$out/AIO-STUDIO.txt"
cp assets/fonts/OFL.txt "$out/OFL-1.1.txt"
case "$target" in
  # The Vulkan loader whisper's Vulkan backend links.
  *-linux-*|*-windows-*) cp licenses/Apache-2.0.txt "$out/" ;;
esac
# Windows runners have python; their python3 may be the Store's stub.
case "$(uname -s)" in
  MINGW*|MSYS*|CYGWIN*) python=python ;;
  *) python=python3 ;;
esac
"$python" packaging/rust-licenses.py "$out/rust-crates.txt" >/dev/null

if [ "$(ffmpeg_license "$target")" = gpl ]; then
  cp licenses/GPL-2.0.txt "$out/"
  cat > "$out/NOTICE.txt" <<NOTICE
Aio Studio for Linux is free of charge: you may use it and pass on
unchanged copies under its author's licence (AIO-STUDIO.txt). It is not
open source.

The FFmpeg $FFMPEG_VERSION it includes is a separate program, built with
--enable-gpl, with x264 and x265, and is covered by the GNU General Public
License version 2 or later (GPL-2.0.txt). The exact source code of FFmpeg
and every library it is built with, and the scripts that build them, are
published beside each download as aio-studio-sources-*.tar at
https://github.com/ChartAndChill/aio-studio.

The other open-source parts and their licences are listed in
THIRD-PARTY.md and rust-crates.txt.
NOTICE
else
  cat > "$out/NOTICE.txt" <<NOTICE
Aio Studio for macOS and Windows is licensed to you by its author under
the author's own licence terms (AIO-STUDIO.txt). It is not open source.

It includes FFmpeg $FFMPEG_VERSION, which is licensed under the GNU Lesser
General Public License version 2.1 or later (LGPL-2.1.txt). This FFmpeg is
built without --enable-gpl and without x264 or x265; it is a separate
program next to the app, which you may replace with your own build of
FFmpeg. Nothing in the app's licence keeps you from changing, rebuilding or
reverse engineering this FFmpeg to debug such changes. The exact source
code of FFmpeg and every library it is built with, and the scripts that
build them, are published beside each download as aio-studio-sources-*.tar
at https://github.com/ChartAndChill/aio-studio.

The other open-source parts and their licences are listed in
THIRD-PARTY.md and rust-crates.txt.
NOTICE
fi
echo "staged the licences of $target in $out"
