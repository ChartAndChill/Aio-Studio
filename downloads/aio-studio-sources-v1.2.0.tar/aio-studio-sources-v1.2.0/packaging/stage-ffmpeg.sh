#!/usr/bin/env bash
# Puts the FFmpeg bundle of one target where the installers pick it up:
# dist/ffmpeg/<target>/ -> dist/ffmpeg/package/ (see crates/aio-gui/Cargo.toml).
#
#   packaging/stage-ffmpeg.sh [target]   (default: the host's Rust target)
set -euo pipefail
cd "$(dirname "$0")/.."
target=${1:-$(rustc -vV | sed -n 's/^host: //p')}
src="dist/ffmpeg/$target"
[ -x "$src/ffmpeg" ] || [ -f "$src/ffmpeg.exe" ] || {
  echo "no FFmpeg bundle in $src (run packaging/ffmpeg/build.sh $target)" >&2
  exit 1
}
rm -rf dist/ffmpeg/package
cp -a "$src" dist/ffmpeg/package
echo "staged $src -> dist/ffmpeg/package"
# The licences that go with this target's bundle (packaging/stage-licenses.sh).
packaging/stage-licenses.sh "$target"
