# Open-source parts of Aio Studio

Aio Studio bundles FFmpeg, built from source by `packaging/ffmpeg/build.sh`
with the libraries below. The exact source archives used for a release are
attached to that release (`aio-studio-sources-*.tar`), together with the
scripts that build them.

| Component | Version | Licence | Platforms | Source |
|---|---|---|---|---|
| FFmpeg | 8.1.3 | GPL-2.0-or-later on Linux (built with `--enable-gpl`); LGPL-2.1-or-later on macOS and Windows | all | https://ffmpeg.org/releases/ffmpeg-8.1.3.tar.xz |
| x264 | b35605ace3ddf7c1a5d67a2eb553f034aef41d55 | GPL-2.0-or-later | Linux only | https://code.videolan.org/videolan/x264 |
| x265 | 4.1 | GPL-2.0-or-later | Linux only | https://download.videolan.org/pub/videolan/x265/ |
| SVT-AV1 | v4.3.0 | BSD-3-Clause-Clear, with the Alliance for Open Media patent licence | all | https://gitlab.com/AOMediaCodec/SVT-AV1 |
| libvpx | 1.17.0 | BSD-3-Clause, with the WebM patent grant | all | https://chromium.googlesource.com/webm/libvpx |
| Opus | 1.5.2 | BSD-3-Clause | all | https://opus-codec.org/ |
| LAME | 3.100 | LGPL-2.0-or-later | all | https://lame.sourceforge.io/ |
| nv-codec-headers | 13.0.19.0 | MIT | Linux, Windows | https://github.com/FFmpeg/nv-codec-headers |
| zlib | 1.3.1 | Zlib | all | https://zlib.net/ |
| FreeType | 2.13.3 | FreeType License (FTL), chosen over GPL-2.0 | all | https://freetype.org/ |
| FriBidi | 1.0.16 | LGPL-2.1-or-later | all | https://github.com/fribidi/fribidi |
| HarfBuzz | 11.2.1 | MIT ("Old MIT") | all | https://github.com/harfbuzz/harfbuzz |
| libass | 0.17.4 | ISC | all | https://github.com/libass/libass |
| whisper.cpp | 1.8.3 | MIT | all | https://github.com/ggml-org/whisper.cpp |
| Vulkan loader | 1.4.341.0 | Apache-2.0 | Linux, Windows | https://github.com/KhronosGroup/Vulkan-Loader |
| Vazirmatn font | (bundled in the app) | SIL Open Font License 1.1 | all | https://github.com/rastikerdar/vazirmatn |

Portions of this software are copyright © The FreeType Project
(www.freetype.org). All rights reserved.

On macOS and Windows, H.264 and HEVC are encoded by the operating system
(VideoToolbox, Media Foundation) or the graphics card, not by x264 or x265,
which those builds do not contain.

The full licence texts are in this folder: `GPL-3.0.txt`, `GPL-2.0.txt`,
`LGPL-2.1.txt`, `Apache-2.0.txt`, `MPL-2.0.txt` and `OFL-1.1.txt`.
`rust-crates.txt` lists the Rust libraries the app is built from, with their
licences and licence texts.
